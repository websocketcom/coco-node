const  chainInt = require('./src/cmd/huobiWs')
chainInt()