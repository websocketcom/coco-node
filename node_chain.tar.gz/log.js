const chainDb = require('./src/service/chain/chainDb')

chainDb().then(console.log)