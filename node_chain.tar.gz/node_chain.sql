/*
 Navicat Premium Data Transfer

 Source Server         : 192.168.1.99
 Source Server Type    : MySQL
 Source Server Version : 50650
 Source Host           : 192.168.1.99:3306
 Source Schema         : node_chain

 Target Server Type    : MySQL
 Target Server Version : 50650
 File Encoding         : 65001

 Date: 28/05/2022 18:54:36
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

SET FOREIGN_KEY_CHECKS = 1;
