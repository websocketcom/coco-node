module.exports = {
    host : '127.0.0.1',
    port : 3306,//端口号
    database : 'coco',//数据库名
    user : 'coco',//数据库用户名
    password : 'coco'//数据库密码
};