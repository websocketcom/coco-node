var currency = {
    queryAll:'SELECT * FROM ea_game_event_currency where status = ?',
};
module.exports = currency;